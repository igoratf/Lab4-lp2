package projeto;

public class Utilidades {
	public static final String LN = System.lineSeparator();

}